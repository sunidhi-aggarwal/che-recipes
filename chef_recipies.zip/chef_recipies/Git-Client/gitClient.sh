#!/bin/bash
echo "Git Client installation starts now....."

 yum install git -y


