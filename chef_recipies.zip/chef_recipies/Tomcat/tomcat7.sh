#!/bin/bash
echo "Tomcat7 installation starts now....."

java -version

cd /tmp
wget http://www.us.apache.org/dist/tomcat/tomcat-7/v7.0.75/bin/apache-tomcat-7.0.75.tar.gz

tar xzf apache-tomcat-7.0.75.tar.gz
mv apache-tomcat-7.0.75 /usr/local/tomcat7

cd /usr/local/tomcat7
./bin/startup.sh

#curl http://<srever_ip>:8080 
